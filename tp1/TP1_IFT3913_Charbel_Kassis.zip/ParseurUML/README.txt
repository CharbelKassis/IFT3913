code source du main: src/uml/main/Main.java

main compile: bin/uml/main/Main.class