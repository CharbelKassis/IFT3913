code source du main: src/uml/main/Main.java

main compile: bin/uml/main/Main.class

Le programe peut se lancer directement avec ParseurUML.jar 